#!/bin/bash
# EPT Reliability Suite setup for macOS (installs for the current user, no administrator password needed)
set -e
VERSION="1.3"
HERE="$(cd "$(dirname "$0")" && pwd)"
SRC="$HERE/app"
APP="$HOME/Applications/EPT Reliability Suite.app"

echo ""
echo "  EPT Reliability Suite  -  Essential Performance Tool for Collaborative Reliability"
echo "  Setup, version $VERSION"
echo ""

if [ ! -f "$SRC/EPT-Reliability-Suite.html" ]; then
  echo "  The setup files were not found next to this installer."
  echo "  Double-click the ZIP file to extract it, then run this installer from the extracted folder."
  exit 1
fi

echo "  [1/3] Building the EPT Reliability Suite app in your Applications folder..."
mkdir -p "$HOME/Applications"
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cp "$SRC/EPT-Reliability-Suite.html" "$APP/Contents/Resources/EPT-Reliability-Suite.html"
cp "$SRC/EPT-Reliability-Suite.icns" "$APP/Contents/Resources/EPT-Reliability-Suite.icns"
cp "$SRC/VERSION.txt" "$APP/Contents/Resources/VERSION.txt" 2>/dev/null || true

cat > "$APP/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleName</key><string>EPT Reliability Suite</string>
  <key>CFBundleDisplayName</key><string>EPT Reliability Suite</string>
  <key>CFBundleIdentifier</key><string>com.duurvextech.eptreliabilitysuite</string>
  <key>CFBundleVersion</key><string>$VERSION</string>
  <key>CFBundleShortVersionString</key><string>$VERSION</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleExecutable</key><string>EPT Reliability Suite</string>
  <key>CFBundleIconFile</key><string>EPT-Reliability-Suite</string>
  <key>LSMinimumSystemVersion</key><string>10.13</string>
</dict></plist>
PLIST

echo "  [2/3] Setting up the launcher..."
cat > "$APP/Contents/MacOS/EPT Reliability Suite" <<'LAUNCH'
#!/bin/bash
HTML="$(cd "$(dirname "$0")/../Resources" && pwd)/EPT-Reliability-Suite.html"
URL="file://${HTML// /%20}"
for B in "Google Chrome" "Microsoft Edge" "Brave Browser" "Chromium"; do
  if [ -d "/Applications/$B.app" ] || [ -d "$HOME/Applications/$B.app" ]; then
    open -na "$B" --args --app="$URL"
    exit 0
  fi
done
open "$HTML"
LAUNCH
chmod +x "$APP/Contents/MacOS/EPT Reliability Suite"
xattr -dr com.apple.quarantine "$APP" 2>/dev/null || true
touch "$APP"

echo "  [3/3] Done."
echo ""
echo "  EPT Reliability Suite is installed in: $APP"
echo "  Open it from Launchpad, Spotlight (type EPT Reliability Suite) or your Applications folder."
echo "  Tip: drag it to the Dock to keep it one click away."
echo ""
echo "  Starting EPT Reliability Suite now..."
open "$APP"
