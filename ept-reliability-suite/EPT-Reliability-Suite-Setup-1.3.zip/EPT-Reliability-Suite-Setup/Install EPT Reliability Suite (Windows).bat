@echo off
title EPT Reliability Suite - Setup
cd /d "%~dp0"
if not exist "%~dp0setup\install-windows.ps1" (
  echo.
  echo   Please extract the ZIP file first:
  echo   right-click the ZIP, choose "Extract All...", then run this file from the extracted folder.
  echo.
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup\install-windows.ps1"
echo.
pause
