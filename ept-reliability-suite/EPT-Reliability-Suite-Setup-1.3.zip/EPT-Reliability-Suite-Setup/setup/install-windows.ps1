# EPT Reliability Suite setup for Windows 10 and 11
# Installs for the current user only (no administrator rights needed).
$ErrorActionPreference = 'Stop'
$AppName   = 'EPT Reliability Suite'
$Version   = '1.3'
$Publisher = 'DuurveX-Tech'
$src       = Join-Path (Split-Path -Parent $PSScriptRoot) 'app'
$dest      = Join-Path $env:LOCALAPPDATA 'EPT Reliability Suite'

function Say($text, $color = 'Gray') { Write-Host $text -ForegroundColor $color }

Clear-Host
Say ''
Say '  EPT Reliability Suite  -  Essential Performance Tool for Collaborative Reliability' 'Cyan'
Say "  Setup, version $Version" 'Cyan'
Say ''

if (-not (Test-Path (Join-Path $src 'EPT-Reliability-Suite.html'))) {
    Say '  The setup files were not found next to this installer.' 'Yellow'
    Say '  Please right-click the ZIP file, choose "Extract All...", then run' 'Yellow'
    Say '  "Install EPT Reliability Suite (Windows)" from the extracted folder.' 'Yellow'
    exit 1
}

try {
    Say '  [1/4] Copying EPT Reliability Suite to your computer...'
    New-Item -ItemType Directory -Force -Path $dest | Out-Null
    # An open EPT Reliability Suite window keeps EPT-Reliability-Suite.html in use, so retry for a few seconds before giving up.
    $copied = $false
    for ($try = 1; $try -le 8 -and -not $copied; $try++) {
        try { Copy-Item -Path (Join-Path $src '*') -Destination $dest -Recurse -Force -ErrorAction Stop; $copied = $true }
        catch [System.IO.IOException] { if ($try -eq 1) { Say '        EPT Reliability Suite seems to be open; waiting for it to be closed...' 'Yellow' }; Start-Sleep -Seconds 2 }
    }
    if (-not $copied) {
        Say ''
        Say '  EPT Reliability Suite is open, so setup cannot replace it.' 'Yellow'
        Say '  If it is already installed, you can simply keep using it from the Desktop icon.' 'Yellow'
        Say '  To reinstall or update: close every EPT Reliability Suite window (and setup windows),' 'Yellow'
        Say '  then double-click "Install EPT Reliability Suite (Windows)" once more.' 'Yellow'
        exit 2
    }
    Copy-Item -Path (Join-Path $PSScriptRoot 'uninstall-windows.ps1') -Destination $dest -Force
    Set-Content -Path (Join-Path $dest 'Uninstall EPT Reliability Suite.bat') -Encoding ASCII -Value @(
        '@echo off',
        'title EPT Reliability Suite - Uninstall',
        'cd /d "%TEMP%"',
        'powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall-windows.ps1"',
        'pause')
    Get-ChildItem -Path $dest -Recurse | Unblock-File -ErrorAction SilentlyContinue

    Say '  [2/4] Finding a browser to run EPT Reliability Suite in its own window...'
    $candidates = @(
        "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
        "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
        "$env:LOCALAPPDATA\Microsoft\Edge\Application\msedge.exe",
        "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
        "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
        "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe")
    $browser = $candidates | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
    $html = Join-Path $dest 'EPT-Reliability-Suite.html'
    $url  = ([System.Uri]$html).AbsoluteUri
    if ($browser) { Say ("        Using " + (Split-Path -Leaf $browser)) } else { Say '        No Edge or Chrome found; your default browser will be used.' }

    Say '  [3/4] Creating Desktop and Start menu shortcuts...'
    $ws = New-Object -ComObject WScript.Shell
    function New-AppShortcut($path) {
        $s = $ws.CreateShortcut($path)
        if ($browser) { $s.TargetPath = $browser; $s.Arguments = "--app=`"$url`"" } else { $s.TargetPath = $html }
        $s.WorkingDirectory = $dest
        $s.IconLocation = (Join-Path $dest 'EPT-Reliability-Suite.ico') + ',0'
        $s.Description = 'EPT Reliability Suite - Essential Performance Tool for Collaborative Reliability'
        $s.Save()
    }
    $desktop  = [Environment]::GetFolderPath('Desktop')
    $programs = [Environment]::GetFolderPath('Programs')
    New-AppShortcut (Join-Path $desktop  'EPT Reliability Suite.lnk')
    New-AppShortcut (Join-Path $programs 'EPT Reliability Suite.lnk')

    Say '  [4/4] Registering EPT Reliability Suite in Settings > Apps...'
    $key = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\DuurveXEPTReliabilitySuite'
    New-Item -Path $key -Force | Out-Null
    $props = @{
        DisplayName     = $AppName
        DisplayVersion  = $Version
        Publisher       = $Publisher
        DisplayIcon     = (Join-Path $dest 'EPT-Reliability-Suite.ico')
        InstallLocation = $dest
        URLInfoAbout    = 'https://duurvextech.com'
        UninstallString = ('cmd.exe /c "' + (Join-Path $dest 'Uninstall EPT Reliability Suite.bat') + '"')
    }
    foreach ($k in $props.Keys) { New-ItemProperty -Path $key -Name $k -Value $props[$k] -PropertyType String -Force | Out-Null }
    foreach ($k in @('NoModify', 'NoRepair')) { New-ItemProperty -Path $key -Name $k -Value 1 -PropertyType DWord -Force | Out-Null }

    Say ''
    Say '  EPT Reliability Suite is installed.' 'Green'
    Say "  Location: $dest"
    Say '  Open it any time from the "EPT Reliability Suite" icon on your Desktop or in the Start menu.'
    Say ''
    Say '  Starting EPT Reliability Suite now...'
    if ($browser) { Start-Process -FilePath $browser -ArgumentList "--app=`"$url`"" } else { Start-Process -FilePath $html }
}
catch {
    Say ''
    Say '  Setup could not finish:' 'Red'
    Say ("  " + $_.Exception.Message) 'Red'
    Say '  See "Troubleshooting" in the EPT Reliability Suite Installation Guide.' 'Yellow'
    exit 1
}
