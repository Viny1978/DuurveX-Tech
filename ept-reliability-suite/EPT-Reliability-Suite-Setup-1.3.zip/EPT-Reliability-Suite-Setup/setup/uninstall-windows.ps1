# EPT Reliability Suite uninstall for Windows
$dest = Join-Path $env:LOCALAPPDATA 'EPT Reliability Suite'
Write-Host ''
Write-Host '  EPT Reliability Suite - Uninstall' -ForegroundColor Cyan
Write-Host ''
Write-Host '  This removes the EPT Reliability Suite program and its shortcuts.'
Write-Host '  Project files you saved (.eptsuite.json) and reports are NOT deleted.'
Write-Host ''
$answer = Read-Host '  Type Y and press Enter to uninstall, or just press Enter to cancel'
if ($answer -notmatch '^[Yy]') { Write-Host '  Cancelled. Nothing was changed.'; exit 0 }

$desktop  = [Environment]::GetFolderPath('Desktop')
$programs = [Environment]::GetFolderPath('Programs')
Remove-Item -Path (Join-Path $desktop  'EPT Reliability Suite.lnk') -Force -ErrorAction SilentlyContinue
Remove-Item -Path (Join-Path $programs 'EPT Reliability Suite.lnk') -Force -ErrorAction SilentlyContinue
Remove-Item -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\DuurveXEPTReliabilitySuite' -Recurse -Force -ErrorAction SilentlyContinue

# The uninstaller runs from inside the install folder, so remove that folder after this window closes.
Start-Process -FilePath 'cmd.exe' -WorkingDirectory $env:TEMP -ArgumentList ('/c ping -n 6 127.0.0.1 >nul & rmdir /s /q "' + $dest + '"') -WindowStyle Hidden
Write-Host ''
Write-Host '  EPT Reliability Suite has been removed.' -ForegroundColor Green
Write-Host '  Projects kept inside the browser (This browser only) stay in Edge or Chrome storage;'
Write-Host '  export any you need as project files before clearing browser data.'
