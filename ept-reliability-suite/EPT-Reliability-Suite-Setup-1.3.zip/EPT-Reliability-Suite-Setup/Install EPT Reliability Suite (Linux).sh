#!/bin/bash
# EPT Reliability Suite setup for Linux desktops (installs for the current user)
set -e
VERSION="1.3"
HERE="$(cd "$(dirname "$0")" && pwd)"
SRC="$HERE/app"
DEST="${XDG_DATA_HOME:-$HOME/.local/share}/ept-reliability-suite"
APPS="${XDG_DATA_HOME:-$HOME/.local/share}/applications"

echo ""
echo "  EPT Reliability Suite  -  Essential Performance Tool for Collaborative Reliability"
echo "  Setup, version $VERSION"
echo ""
if [ ! -f "$SRC/EPT-Reliability-Suite.html" ]; then
  echo "  The setup files were not found. Extract the whole ZIP first, then run this installer from the extracted folder."
  exit 1
fi

echo "  [1/3] Copying EPT Reliability Suite to $DEST ..."
mkdir -p "$DEST" "$APPS"
cp "$SRC/EPT-Reliability-Suite.html" "$SRC/EPT-Reliability-Suite.png" "$DEST/"
cp "$SRC/VERSION.txt" "$DEST/" 2>/dev/null || true

echo "  [2/3] Creating the launcher and menu entry..."
cat > "$DEST/ept-reliability-suite" <<'LAUNCH'
#!/bin/bash
HTML="$(cd "$(dirname "$0")" && pwd)/EPT-Reliability-Suite.html"
URL="file://${HTML// /%20}"
for B in microsoft-edge microsoft-edge-stable google-chrome google-chrome-stable chromium chromium-browser brave-browser; do
  if command -v "$B" >/dev/null 2>&1; then exec "$B" --app="$URL"; fi
done
exec xdg-open "$HTML"
LAUNCH
chmod +x "$DEST/ept-reliability-suite"

cat > "$APPS/ept-reliability-suite.desktop" <<DESK
[Desktop Entry]
Type=Application
Name=EPT Reliability Suite
Comment=Essential Performance Tool for Collaborative Reliability
Exec="$DEST/ept-reliability-suite"
Icon=$DEST/EPT-Reliability-Suite.png
Terminal=false
Categories=Science;Engineering;Office;
DESK
chmod +x "$APPS/ept-reliability-suite.desktop"
if [ -d "$HOME/Desktop" ]; then cp "$APPS/ept-reliability-suite.desktop" "$HOME/Desktop/EPT Reliability Suite.desktop"; chmod +x "$HOME/Desktop/EPT Reliability Suite.desktop"; fi

cat > "$DEST/uninstall.sh" <<UNI
#!/bin/bash
rm -f "$APPS/ept-reliability-suite.desktop" "$HOME/Desktop/EPT Reliability Suite.desktop"
rm -rf "$DEST"
echo "EPT Reliability Suite has been removed. Saved project files were not touched."
UNI
chmod +x "$DEST/uninstall.sh"

echo "  [3/3] Done. EPT Reliability Suite is in your applications menu."
echo "  To remove it later, run: $DEST/uninstall.sh"
if [ -z "$EPT_NO_LAUNCH" ]; then ( "$DEST/ept-reliability-suite" >/dev/null 2>&1 & ); fi
